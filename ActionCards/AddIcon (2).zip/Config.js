var TOTAL_PAGES = 1;
var SHOW_SUBMIT_IN_HEADER_SINGLEPAGE = true;
var MAX_ATTACHMENT_COUNT = 4;

var AUTO_FILL_FIELDS = [
    { "name": "INPUT1" },
    { "contact": "INPUT2" }
]

var SLIDER_ELEMENT_DETAILS = {
    "SLIDER1": {
        "min": "0",
        "max": "100",
        "value": "50"
    }
}

var submitIds = ["INPUT1", "INPUT2", "LIST_0", "INPUT4", "INPUT5", "INPUT6", "LIST_1", "INPUT8", "INPUT9"]

var OPTIONAL_IDS = {
    "page_1": []
}